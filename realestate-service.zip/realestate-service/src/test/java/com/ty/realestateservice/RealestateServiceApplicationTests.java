package com.ty.realestateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealestateServiceApplicationTests {

	@Test
	void contextLoads() {
		
		
		
	}
	
	

}
